package Week2;

public class BoundingBox {

	public BoundingBox(){
		
		
	}

//**This method allows to check any points whether or not in the boundingbox*/	
public static boolean isInside(int x,int y, int ulx, int uly, int lrx, int lry){
	if (ulx<lrx && uly>lry && ulx<x && lrx>x && lrx>x && uly>y && lry<y){
		return true;}  
		else {return false;}
	
}}