package Week2;

public class HW2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Point aPoint=new Point();  //**Create a new object of point named aPoint*/
          BoundingBox aBoundingBox=new BoundingBox();  //**Create a new object of boundingbox named aBoundingbox*/
          Polygon aPolygon=new Polygon();  //**Create a new object of polygon named aPolygon*/
          Polyline aPolyline=new Polyline();  //**Create a new object of polyline named aPolyline*/
          
          System.out.println("The distance between point (3,5) and (2,7) is "+aPoint.distance(3,5,2,7));  //*Calculate the distance between point (3,5) and (2,7)*/
          
          //**input a polygon's coordinate and create a bounding box of this polygon*/
  		  int p1x=2; int p1y=1;   
  		  int minx=p1x; int miny=p1y; int maxx=p1x; int maxy=p1y;  //*Initialize the bounding box*/
  		
  		  int p2x=3; int p2y=-1;
  		  if (p2x<minx){minx=p2x;} //*If the second point x is smaller than leftlimit's x, then set the leftlimit's x to the second point x*/
  		  else if (p2x>maxx) {maxx=p2x;} //*If the second point x is larger than rightlimit's x, then set the rightlimit's x to the second point x*/
  		  if (p2y<miny){miny=p2y;} //*If the second point y is smaller than lowerlimit's y, then set the lowerlimit's y to the second point y*/
  		  else if (p2y>maxy) {maxy=p2y;} //*If the second point y is larger than upperlimit's y, then set the upperlimit's y to the second point y*/
  		
  		  int p3x=4; int p3y=1;
  		  if (p3x<minx){minx=p3x;} 
  		  else if (p3x>maxx) {maxx=p3x;}
  		  if (p3y<miny){miny=p2y;} 
  		  else if (p3y>maxy) {maxy=p3y;}
  		
  		  int p4x=4; int p4y=3;
  		  if (p4x<minx){minx=p4x;} 
  		  else if (p4x>maxx) {maxx=p4x;}
  		  if (p4y<miny){miny=p4y;} 
  		  else if (p4y>maxy) {maxy=p4y;}
  		
  		  int p5x=3; int p5y=3;
  		  if (p5x<minx){minx=p5x;} 
  		  else if (p5x>maxx) {maxx=p5x;}
  		  if (p5y<miny){miny=p5y;} 
  		  else if (p5y>maxy) {maxy=p5y;}
  		
  		  System.out.println("The point (3,1) in the bounding box is "+aBoundingBox.isInside(3,1,minx,maxy,maxx,miny)); //**Checking the point whether or not in the bounding box/
  		  System.out.println("The point (4,6) in the bounding box is "+aBoundingBox.isInside(4,6,minx,maxy,maxx,miny));
  		  
  	      int [] plx=new int[3];
  	      int [] ply=new int[3];
  		  aPolyline.addPoint(plx,ply,3,5,0);  //**Add the first point to the polygon*/
  		  aPolyline.addPoint(plx,ply,3,7,1);  //**Add the second point to the polygon*/
  		  aPolyline.addPoint(plx,ply,4,9,2);  //**Add the third point to the polygon*/
  		  for (int j=0;j<3;j++){   //*Print out the each point's coordinate of the polyline*/
  			System.out.println("The "+(j+1)+"th point of polyline is "+"("+plx[j]+","+ply[j]+").");
  		  }
  		  
  		  
  		  
  		  int [] pgx=new int [7];
  		  int [] pgy=new int [7];
  		  aPolygon.addPoint(pgx,pgy,0,0,0);  //**Add the first point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,3,0,1);  //**Add the second point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,4,2,2);  //**Add the third point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,3,4,3);  //**Add the fourth point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,2,6,4);  //**Add the fifth point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,-2,2,5);  //**Add the sixth point to the polygon*/
  		  aPolygon.addPoint(pgx,pgy,0,0,6);  //**Add the seven point to the polygon*/
  		  if (pgx[6]==pgx[0]&&pgy[6]==pgy[0])    //**Checking the polygon is closed or not*/
  		    {System.out.println("This polygon is closed");  //*Print out the message of the closed polygon*/
  		     for (int k=0;k<7;k++){      //*Print out the each point's coordinate of the polygon*/
  		     System.out.println("The "+(k+1)+"th Point of the polygon is "+"("+pgx[k]+","+pgx[k]+").");
}}
  		  else{System.out.println("This polygon is not closed");}  //**Print out the message for unclosed polygon**//
  		  
  		
  		
	}

}
