package Week2;

public class Polygon {


	public Polygon(){

		
	}
	//*This method allows add points to the array of polygon's points' coordinates/
	public void addPoint(int px[],int py[], int x, int y, int i){
		px[i]=x;   //**Add the x coordinate to the array of polygon x coordinate*/
		py[i]=y;   //**Add the y coordinate to the array of polygon y coordinate*/
	
		
	    
	}
}
	