package Week2;

public class Point {

	public Point(){
	
		
	}
	//**This method allows calculate the distance between two point, parameter are (point 1's x coordinate,point 1's y coordinate,point 2's x coordinate,point 2's y coordinate)*/
	public static double distance(int x1, int y1, int x2, int y2){
		return Math.sqrt(Math.pow(y2-y1,2.0)+Math.pow(x2-x1,2.0));
	}
	
}