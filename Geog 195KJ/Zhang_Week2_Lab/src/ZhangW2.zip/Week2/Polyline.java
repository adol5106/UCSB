package Week2;

public class Polyline {

 	public Polyline(){
 		

 	}
 	//*This method allows add points to the array of the polyline's points' coordinates/
	public void addPoint(int px[],int py[], int x,int y, int i){
		px[i]=x;   //**Add the x coordinate to the array of polyline x coordinate*/
		py[i]=y;   //**Add the y coordinate to the array of polyline y coordinate*/
		
	    
	}
}
	