package edu.ucsb.geog.w2;

public class Number {

	public int theNumber;
	public Number(int aInt){
		theNumber = aInt;
	}

	public static void addOne(Number aNumber) {
		aNumber.theNumber++;
	}
}