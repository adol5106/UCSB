package Week5;

import java.util.ArrayList;

public class disaster extends Polygon{

		
	public disaster() {  
}

    // Returns the list of points forming the disaster polygon
    public ArrayList<Point> getDisaster(){
    	

		return polygon;

    	
	}


}