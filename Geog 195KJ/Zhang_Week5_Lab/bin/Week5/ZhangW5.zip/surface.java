package Week5;

public interface surface {
	
	
	public double computeArea(); //compute the shape area

	public int dimensionality(); //Get the shape dimensionality
	
	public double Perimeter(); //Get the shape perimeter
	
}
